# SNPpools #

SNPpools is a R package (R Core Team 2016) comprised of four primary functions: parent.assign.fun, sim.parent.assign.fun, snp.param.indiv.fun and snp.param.pools.fun.

### What is SNPpools ###

* SNPpools implements the methods of Hamilton et al (in prep) Methods of parentage assignment for pooled samples using low-density SNP data.  
* The functions each have a R help documentation.  Example data sets and examples of parentage assignment are detailed in this documentation.

### To install polyAinv in R ###

* #Obtain and save the tar.gz file for the package
* #Then, in R, run the following
* install.packages([path_to_tar.gz_file], repos = NULL, type="source")
* #If you get an error "ERROR: dependency '[package name]' is not available for package 'SNPpools'" then install the dependent package from CRAN and then rerun the previous install.packages command
* library(SNPpools)
* #Read help on the four primary functions
* help ("parent.assign.fun")
* help ("sim.parent.assign.fun")
* help ("snp.param.indiv.fun")
* help ("snp.param.pools.fun")

### Contact details ###

* <matthew.hamilton@csiro.au>

### References ###

* Hamilton et al (in prep) Methods of parentage assignment for pooled samples using low-density SNP data.
* R Core Team (2016) R: A language and environment for statistical computing. R Foundation for Statistical Computing, Vienna, Austria
